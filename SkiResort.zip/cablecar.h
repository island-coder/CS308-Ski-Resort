float PI = 3.141;

void drawWindow()
{

    glPushMatrix();
    glColor3f(0.8,0.0,0.0);
    glBegin(GL_QUADS);
    glVertex3f(0,1,1);
    glVertex3f(0,1,0);
    glVertex3f(0,0,0);
    glVertex3f(0,0,1);
    glEnd();
    glPopMatrix();

}

void drawBody()
{
    glPushMatrix();
    glColor3f(0.8, 0.8, 0.8);
    glutSolidCube(1);
    glPopMatrix();

    glPushMatrix();
    glColor3f(0.6, 0.3, 0.4);
    glTranslatef(0, 0.5, -0.5);
    gluCylinder(gluNewQuadric(), 0.5, 0.5, 1, 30, 30);
    glPopMatrix();

    glPushMatrix();
    glColor3f(0.6, 0.3, 0.4);
    glTranslatef(0, -0.5, -0.5);
    gluCylinder(gluNewQuadric(), 0.5, 0.5, 1, 30, 30);
    glPopMatrix();


}

void drawBodyWithWindows()
{
    drawBody();

    glPushMatrix();
    glTranslatef(0.52,-0.2,0.1);
    glScalef(0.5,0.6,0.4);
    drawWindow();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.52,-0.2,-0.5);
    glScalef(0.5,0.6,0.4);
    drawWindow();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-0.52,-0.2,0.1);
    glScalef(0.5,0.6,0.4);
    drawWindow();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-0.52,-0.2,-0.5);
    glScalef(0.5,0.6,0.4);
    drawWindow();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-0.35, -0.2, 0.53);
    glRotatef(90,0,1,0);
    glScalef(1, 0.6, 0.7);
    drawWindow();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-0.35, -0.2, -0.53);
    glRotatef(90, 0, 1, 0);
    glScalef(1, 0.6, 0.7);
    drawWindow();
    glPopMatrix();

}


void drawHandleCurvedBottom(float radius)
{

    float angle = 0,height=0.5;
    int n = 30;

    glPushMatrix();
    glColor3f(0.40,0.4,0.5);

    glBegin(GL_QUAD_STRIP);
    for (int c = 0; c <= n/4; c++)
    {
        double x = radius * cos(angle);
        double z = radius * sin(angle);
        glVertex3f(x, 0, z);
        glVertex3f(x, height, z);

        angle = angle + ((2 * PI) / n);
    }
    glEnd();

    angle = 0;

    glBegin(GL_QUAD_STRIP);
    for (int c = 0; c <= n / 4; c++)
    {
        double x = radius * cos(angle);
        double z = radius * sin(angle);
        glVertex3f(x * 0.8, 0, z * 0.8);
        glVertex3f(x * 0.8, height, z * 0.8);

        angle = angle + ((2 * PI) / n);
    }
    glEnd();

    angle = 0;

    glBegin(GL_QUAD_STRIP);
    for (int c = 0; c <= n / 4; c++)
    {
        double x = radius * cos(angle);
        double z = radius * sin(angle);
        glVertex3f(x, height, z);
        glVertex3f(x * 0.8, height, z * 0.8);

        angle = angle + ((2 * PI) / n);
    }
    glEnd();

    angle = 0;

    glBegin(GL_QUAD_STRIP);
    for (int c = 0; c <= n / 4; c++)
    {
        double x = radius * cos(angle);
        double z = radius * sin(angle);
        glVertex3f(x, 0, z);
        glVertex3f(x * 0.8, 0, z * 0.8);

        angle = angle + ((2 * PI) / n);
    }
    glEnd();

    glPopMatrix();
}


void arch(float radius)
{

    float angle = 0, height = 0.5;
    int n = 30;

    glPushMatrix();
    glColor3f(0.40, 0.4, 0.5);

    glBegin(GL_QUAD_STRIP);
    for (int c = 0; c <= n / 4; c++)
    {
        double x = radius * cos(angle);
        double z = radius * sin(angle);
        glVertex3f(x, 0, z);
        glVertex3f(x, height, z);

        angle = angle + ((2 * PI) / n);
    }
    glEnd();

    angle = 0;

    glBegin(GL_QUAD_STRIP);
    for (int c = 0; c <= n / 4; c++)
    {
        double x = radius * cos(angle);
        double z = radius * sin(angle);
        glVertex3f(x * 0.8, 0, z * 0.8);
        glVertex3f(x * 0.8, height, z * 0.8);

        angle = angle + ((2 * PI) / n);
    }
    glEnd();

    angle = 0;

    glBegin(GL_QUAD_STRIP);
    for (int c = 0; c <= n / 4; c++)
    {
        double x = radius * cos(angle);
        double z = radius * sin(angle);
        glVertex3f(x, height, z);
        glVertex3f(x * 0.8, height, z * 0.8);

        angle = angle + ((2 * PI) / n);
    }
    glEnd();

    angle = 0;

    glBegin(GL_QUAD_STRIP);
    for (int c = 0; c <= n / 4; c++)
    {
        double x = radius * cos(angle);
        double z = radius * sin(angle);
        glVertex3f(x, 0, z);
        glVertex3f(x * 0.8, 0, z * 0.8);

        angle = angle + ((2 * PI) / n);
    }
    glEnd();

    glPopMatrix();
}


void drawHandeTop()
{
    glPushMatrix();
    glColor3f(0.40, 0.1, 0.5);
    glScalef(0.5,0.5,1);
    glTranslatef(0,0.5,0);
    glutSolidCube(1);
    glPopMatrix();
}

void drawHandeBottom()
{
    glPushMatrix();

    glColor3f(0.40, 0.1, 0.2);
    glScalef(0.1, 0.5, 1);

    glutSolidCube(1);


    glPopMatrix();
}


void drawHandle()
{

    glPushMatrix();
    glTranslatef(0, 1, 0);
    glRotatef(90,1,0,0);


    drawHandeTop();

    glPushMatrix();
    glTranslatef(-1, 0.25, 1.4);
    glRotatef(90, 0, 1, 0);
    drawHandeBottom();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-0.8, 0, 0.5);
    drawHandleCurvedBottom(1);
    glPopMatrix();

    glPopMatrix();


}
void drawWire()
{
    glPushMatrix();
    glColor3f(0.3, 0.3, 0.3);
    glTranslatef(1, 2,0);
    glRotatef(-90,1,0,0);
    gluCylinder(gluNewQuadric(),0.05,0.05,2.5,30,30);
    glPopMatrix();
}

void drawCableCar()
{
    glPushMatrix();
    glScalef(3,3,5);
    drawBodyWithWindows();

    //glPushMatrix();
    //glRotatef(90,1,0,0);
    //drawBody();
    //glPopMatrix();

    glPushMatrix();
    glScalef(1, 1, 0.5);
    glTranslatef(1, 1.4,-0.1);
    drawHandle();
    glPopMatrix();


    glPushMatrix();
    drawWire();
    glPopMatrix();



    glPopMatrix();


}
