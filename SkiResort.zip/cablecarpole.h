void drawBase()
{
    glColor3f(0.3,0.30,.3);
    glPushMatrix();
    glScalef(8,3,3);
    glutSolidCube(1);
    glPopMatrix();
}
void drawVerticalPole(float height)
{
    glPushMatrix();
    glColor3f(0.8,0.8,0.7);
    glRotatef(-90,1,0,0);
    gluCylinder(gluNewQuadric(),1,0.5,height,30,30);
    glPopMatrix();

}
void drawHorizontalPole(float height)
{
    float k =0.25;
    glPushMatrix();
    glColor3f(0.7,0.7,0.7);
    glRotatef(90,0,1,0);
    gluCylinder(gluNewQuadric(),0.5 * k,1 * k,height/2,30,30);
    glPopMatrix();
    glPushMatrix();
    glRotatef(-90,0,1,0);
    gluCylinder(gluNewQuadric(),0.5* k,1* k,height/2,30,30);
    glPopMatrix();

}
void drawTPole(float height)
{
    drawBase();
    glPushMatrix();
    glTranslatef(0,1.5,0);
    drawVerticalPole(height);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(0,height+1,0);
    drawHorizontalPole(height);
    glPopMatrix();

}
