void drawWalls()
{
    glPushMatrix();
    glColor3f(0.8,0.7,0.7);
    glutSolidCube(1);
    glPopMatrix();


}

void drawRoof()
{
    glPushMatrix();
    glColor3f(0.4,0.2,0.2);
    glBegin(GL_QUADS);
    glVertex3f(0,1,1.2);
    glVertex3f(0,1,-0.2);
    glVertex3f(1,0,-0.2);
    glVertex3f(1,0,1.2);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3f(0.4,0.2,0.2);
    glBegin(GL_QUADS);
    glVertex3f(0,1,1.2);
    glVertex3f(0,1,-0.2);
    glVertex3f(-1,0,-0.2);
    glVertex3f(-1,0,1.2);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3f(0.8,0.7,0.7);
    glBegin(GL_POLYGON);
    glVertex3f(-1*0.5,0.5,0);
    glVertex3f(0,1,0);
    glVertex3f(1*0.5,0.5,0);
    glEnd();
    glPopMatrix();

    glPushMatrix();
    glColor3f(0.8,0.7,0.7);
    glBegin(GL_POLYGON);
    glVertex3f(-1*0.5,0.5,1);
    glVertex3f(0,1,1);
    glVertex3f(1*0.5,0.5,1);
    glEnd();
    glPopMatrix();

}

void drawFence(int n)
{

    glPushMatrix();
    glColor3f(0.8,0.7,0.7);
    float startx=-0.5,x=0;
    float endx=0.5;
    float divs=5;
    float gap=(endx-startx)/divs;
    for(int i=0; i<n; i++)
    {
        glPushMatrix();
        glTranslatef(x,0,0);
        glRotatef(-90,1,0,0);
        gluCylinder(gluNewQuadric(),gap*0.2,gap*0.2,gap*1.5,30,30);
        glPopMatrix();
        x+=gap;
    }
    glPopMatrix();
}

void drawFences()
{
    glPushMatrix();
    glTranslatef(-0.3,0,1.2);
    drawFence(4);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0.4,0,1.2);
    glRotatef(90,0,1,0);
    drawFence(6);
    glPopMatrix();


    glPushMatrix();
    glTranslatef(-0.4,0,1.2);
    glRotatef(90,0,1,0);
    drawFence(6);
    glPopMatrix();

}

void drawLodge()
{

    glPushMatrix();
    glScalef(5,5,5);

    glPushMatrix();
    glTranslatef(0,0.5,0);
    drawWalls();
    glPushMatrix();
    glTranslatef(0,0,-0.5);
    drawRoof();
    glPopMatrix();

    glPopMatrix();

    glPushMatrix();
    drawFences();
    glPopMatrix();

    glPopMatrix();

}
